# Team Git Workflow for .NET API Project

This document describes a step-by-step workflow for a team of 4 people collaborating on a .NET API project using Git. Each person works on a different part of the project, and integration is managed using branches and Git commands.

---

## Team Roles

- **Person 1:** Model (e.g., `Student.cs`)
- **Person 2:** Entity Framework Core (DbContext, migrations)
- **Person 3:** Controller (e.g., `StudentController.cs`)
- **Person 4:** Integration and Git management

---

## 1. Initial Setup (Person 4 or Team Lead)

1. **Create a new repository on GitHub** (e.g., `TeamApiProject`).
2. **Clone the repo locally:**
   ```sh
   git clone https://github.com/org-or-user/TeamApiProject.git
   cd TeamApiProject
   ```
3. **Create a new .NET Web API project:**
   ```sh
   dotnet new webapi -n TeamApiProject
   cd TeamApiProject
   ```
4. **Push the initial code:**
   ```sh
   git add .
   git commit -m "Initial API project"
   git push -u origin main
   ```

---

## 2. Each Person Creates Their Own Branch

Each person clones the repo and creates a branch for their work:

```sh
git clone https://github.com/org-or-user/TeamApiProject.git
cd TeamApiProject
git checkout -b <your-feature-branch>
```
- Person 1: `git checkout -b model-student`
- Person 2: `git checkout -b efcore-setup`
- Person 3: `git checkout -b student-controller`
- Person 4: `git checkout -b integration`

---

## 3. Each Person Works on Their Part

### Person 1 (Model)
- Edits/creates `Student.cs` in the `Models` folder.
- Stages and commits:
  ```sh
  git add Models/Student.cs
  git commit -m "Add Student model"
  git push -u origin model-student
  ```

### Person 2 (EF Core)
- Sets up `AppDbContext.cs`, adds migrations, etc.
- Stages and commits:
  ```sh
  git add Data/AppDbContext.cs
  git commit -m "Add EF Core DbContext"
  git push -u origin efcore-setup
  ```

### Person 3 (Controller)
- Creates `StudentController.cs` in the `Controllers` folder.
- Stages and commits:
  ```sh
  git add Controllers/StudentController.cs
  git commit -m "Add Student controller"
  git push -u origin student-controller
  ```

### Person 4 (Integration)
- Waits for others to push, then pulls all branches:
  ```sh
  git fetch
  ```

---

## 4. Integration (Person 4)

1. **Switch to integration branch:**
   ```sh
   git checkout integration
   ```
2. **Merge each feature branch:**
   ```sh
   git merge origin/model-student
   git merge origin/efcore-setup
   git merge origin/student-controller
   ```
   - Resolve any merge conflicts if they appear.
3. **Test the integrated code.**
4. **Commit and push the integrated branch:**
   ```sh
   git add .
   git commit -m "Integrate model, EF Core, and controller"
   git push -u origin integration
   ```

---

## 5. Final Merge to Main

- Once integration is tested, Person 4 (or the team lead) merges `integration` into `main`:
  ```sh
  git checkout main
  git pull
  git merge integration
  git push
  ```

---

## 6. Keeping Up to Date

- Each person should regularly pull from `main` to keep their branch up to date:
  ```sh
  git checkout <your-feature-branch>
  git pull origin main
  # or, to rebase:
  git fetch origin
  git rebase origin/main
  ```

---

## Visual Workflow

```mermaid
gitGraph
   commit id: "Initial API project" tag: "main"
   branch model-student
   commit id: "Add Student model"
   branch efcore-setup
   commit id: "Add EF Core DbContext"
   branch student-controller
   commit id: "Add Student controller"
   branch integration
   merge model-student
   merge efcore-setup
   merge student-controller
   commit id: "Integrate model, EF Core, and controller"
   checkout main
   merge integration
```

---

## Key Git Commands Used

- `git checkout -b <branch>` — create and switch to a new branch
- `git add <file>` — stage changes
- `git commit -m "message"` — commit changes
- `git push -u origin <branch>` — push branch to remote
- `git fetch` — get all remote branches
- `git merge <branch>` — merge another branch into current
- `git pull` — update local branch with remote changes

---

## Summary

- **Each person works on their own branch.**
- **Integration is done by merging all feature branches.**
- **Final tested code is merged into `main`.**
- **Everyone keeps their branch up to date with `main`.** 