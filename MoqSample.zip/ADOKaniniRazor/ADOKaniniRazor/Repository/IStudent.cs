﻿namespace ADOKaniniRazor.Repository
{
    public interface IStudent
    {
        List<Student> GetAllStudents();
    }
}
