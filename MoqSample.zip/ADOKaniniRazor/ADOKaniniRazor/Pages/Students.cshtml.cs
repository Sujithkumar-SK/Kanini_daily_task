using ADOKaniniRazor.Repository;
using ADOKaniniRazor.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace ADOKaniniRazor.Pages
{
    public class StudentsModel : PageModel
    {

        private readonly IStudent _service;
        public List<Student> Students { get; set; } = new();
        public StudentsModel(IStudent ser)
        {
            _service = ser;
        }
        public void OnGet()
        {
           Students = _service.GetAllStudents();

        }
        
    }
}
