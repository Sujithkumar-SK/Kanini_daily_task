using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ADOKaniniRazor.Pages
{
    public class SampleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
