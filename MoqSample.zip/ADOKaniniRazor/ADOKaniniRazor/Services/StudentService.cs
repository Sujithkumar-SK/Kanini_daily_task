﻿using ADOKaniniRazor.Repository;
using Microsoft.Data.SqlClient;

namespace ADOKaniniRazor.Services
{
    public class StudentService : IStudent
    {
        private readonly IConfiguration _configuration;

        public StudentService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public virtual List<Student> GetAllStudents()
        {
            var Students = new List<Student>();

            string connstring = _configuration.GetConnectionString("NewConnection");
            using (SqlConnection con = new SqlConnection(connstring))
            {
                con.Open();

                string query = "Select * from students";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Students.Add(new Student
                    {
                        Id = Convert.ToInt32(reader["id"]),
                        Name = reader["name"].ToString(),
                        Email = reader["email"].ToString(),
                        JoiningDate = Convert.ToDateTime(reader["join_date"])
                    });
                }
            }
                
            return Students;
        }
    }
}
