using ADOKaniniRazor;
using ADOKaniniRazor.Pages;
using ADOKaniniRazor.Repository;
using ADOKaniniRazor.Services;
using Moq;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            //Arrange
            var studentService = new Mock<IStudent>();

            studentService.Setup(s => s.GetAllStudents()).Returns(new List<Student>
            {
                new Student{Id=11,Name="Anu",Email="anu@gmail.com",JoiningDate=new DateTime(),Department="CSE",IsPlaced=true},
                 new Student{Id=12,Name="Priya",Email="anu@gmail.com",JoiningDate=new DateTime(),Department="CSE",IsPlaced=true}
            });

            var stmdl = new StudentsModel(studentService.Object);
            //Act
            stmdl.OnGet();
            //Assert
            Assert.NotNull(stmdl.Students);
            Assert.Equal(11, stmdl.Students[0].Id);
            Assert.Equal("Anu",stmdl.Students[0].Name);
            Assert.Equal("Priya", stmdl.Students[1].Name);
            Assert.Equal(2, stmdl.Students.Count);
        }
    }
}