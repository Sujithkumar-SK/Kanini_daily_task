﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleADOKanini
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //Establishing connection
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();

            SqlCommand cmmd = new SqlCommand("select * from Product", conn);

            SqlDataReader sdr = cmmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(sdr);

            dataGridView1.DataSource = dataTable;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();

            SqlCommand cmmd = new SqlCommand("select * from Product", conn);

            SqlDataReader sdr = cmmd.ExecuteReader();

            DataTable dataTable = new DataTable();
            dataTable.Load(sdr);

            dataGridView1.DataSource = dataTable;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
           
            int id = int.Parse(txtproid.Text);
            string nm = txtproname.Text;
            decimal price = Convert.ToDecimal(txtprice.Text);
            ProductService ps = new ProductService();
            ps.AddProduct(id, nm, price);
            //5.Display the result
            MessageBox.Show("Record Inserted Successfully");
            //6.Close the connection
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();
            int id = int.Parse(txtproid.Text);
            SqlCommand cmd = new SqlCommand("select * from Product where proid=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataReader sdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(sdr);
            dataGridView1.DataSource = dt;

            //if (sdr.Read())
            //{
            //    txtproid.Text = sdr["proid"].ToString();
            //    txtproname.Text = sdr["proname"].ToString();
            //    txtprice.Text = sdr["price"].ToString();

            //    txtproid.Enabled = false;
            //}
            //else
            //{
            //    MessageBox.Show("No product found with the given ID.");
            //}


        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();
            SqlCommand cmd = new SqlCommand("select count(*) from Product", conn);
            int count =(int) cmd.ExecuteScalar();
            MessageBox.Show($"Total No: of Products:{count}");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();

            int id = int.Parse(txtproid.Text);
            string nm = txtproname.Text;
            decimal price = Convert.ToDecimal(txtprice.Text);
            SqlCommand cmd = new SqlCommand("update Product set proname=@name, price=@price where proid=@id",conn);
            cmd.Parameters.AddWithValue("@name", nm);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated Successfully");
            conn.Close();

        }
    }
}
