﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleADOKanini
{
    public class ProductService : IProduct
    {
        private readonly string _ser;

        public ProductService()
        {
           // _ser = connectionstring;
        }

        public void AddProduct(int id, string prname, decimal price)
        {
            SqlConnection conn = new SqlConnection("server=DESKTOP-7C6F9K9\\SQLEXPRESS;database=kanini;integrated security=true;trustservercertificate=true;");
            conn.Open();         
            SqlCommand cmd = new SqlCommand("insert into Product values(@pid,@name,@price)", conn);
            cmd.Parameters.AddWithValue("@pid", id);//mapping c# varaible with db var
            cmd.Parameters.AddWithValue("@name", prname);
            cmd.Parameters.AddWithValue("@price", price);
            //4.Execute the command
            cmd.ExecuteNonQuery();
        }
    }
}
