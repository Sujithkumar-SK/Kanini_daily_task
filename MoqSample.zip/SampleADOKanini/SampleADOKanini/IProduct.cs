﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleADOKanini
{
    public interface IProduct
    {
        void AddProduct(int id, string prname, decimal price);
    }
}
