using Moq;
using SampleADOKanini;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
           var ser = new Mock<IProduct>();
            int pid = 11;
            string name = "laptop";
            decimal price = 90000;

            ser.Object.AddProduct(pid, name, price);

            ser.Verify(x => x.AddProduct(pid, name, price));
            

        }
    }
}