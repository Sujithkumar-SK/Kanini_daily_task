﻿namespace SampleDISoftura.Models
{
    public class DIModel
    {
        public string SingletonTime { get; set; }
        public string ScopedTime { get; set; }
        public string TransientTime { get; set; }
    }
}
