﻿namespace SampleDISoftura.Interface
{
    public interface ITransient
    {
        string Time { get; set; }
    }
}
