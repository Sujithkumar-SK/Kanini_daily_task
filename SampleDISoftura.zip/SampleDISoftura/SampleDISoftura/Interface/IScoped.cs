﻿namespace SampleDISoftura.Interface
{
    public interface IScoped
    {
        string Time { get; set; }
    }
}
