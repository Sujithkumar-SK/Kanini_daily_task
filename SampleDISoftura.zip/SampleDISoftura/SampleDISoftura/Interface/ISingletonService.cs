﻿namespace SampleDISoftura.Interface
{
    public interface ISingletonService
    {
        string Time { get; set; }
    }
}
